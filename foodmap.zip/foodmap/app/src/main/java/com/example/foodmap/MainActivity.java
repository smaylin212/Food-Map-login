package com.example.foodmap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText Correo;
    EditText Password;
    Button Login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Correo = (EditText)findViewById(R.id.etcorreo);
        Password = (EditText)findViewById(R.id.etpassword);
        Login = (Button) findViewById(R.id.iniciar_sesion);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Nombrecorreo;
                String ContraseñaUsuario;
                Nombrecorreo = Correo.getText().toString();
                ContraseñaUsuario = Password.getText().toString();
                if ((Nombrecorreo.equals("admin")) && (ContraseñaUsuario.equals("12345"))) {
                    Intent intent = new Intent(MainActivity.this, Pantalla2.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(  MainActivity.this, "Error de Login", Toast.LENGTH_LONG).show();

                }
        }




        });
    }
}